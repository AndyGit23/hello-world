package grafica;

import java.util.ArrayList;

import main.Rotazione;

public class Disegna {
	
	public void disegna(double[] input){
		
		int[] inputInt = new int[input.length];
		for (int i = 0; i < input.length; i++) {
			inputInt[i] = (int) input[i];
		}
//		System.out.println("Input");
//		for (int i = 0; i < inputInt.length; i++) {
//			System.out.println(inputInt[i]);
//		}
//		System.out.println("Dis");
//		for (int i = 0; i < inputInt.length; i++) {
//			int l = inputInt[i];
//			for (int numero = 0; numero < l; numero++) {
//				System.out.print("*");
//			}
//			System.out.println("");
//		}
		
		ArrayList<String[]> matrice = new ArrayList<String[]>();
		for (int i = 0; i < inputInt.length; i++) {
			
			int dim = inputInt[i];
			
			String a[] = new String[dim];
			for (int j = 0; j < a.length; j++) {
				a[j] = "*";
			}
			matrice.add(a);
		
		}
		//System.out.println("matrice =" + matrice);
		for (int i = 0; i < matrice.size(); i++) {
			String e[] = matrice.get(i);
			for (int j = 0; j < e.length; j++) {
				//System.out.print("e[" + i + "][" + j + "] = " + e[j] + " , ");
			}
			//System.out.println("");
			
		}
		
		
		int dimMatrice = matrice.size();
		int max = this.trovaMax(inputInt);
		//System.out.println("max =" + max);
		String matrice2[][] = new String[dimMatrice][max];
		for (int i = 0; i < matrice.size(); i++) {
			String e[] = matrice.get(i);
			for (int j = 0; j < e.length; j++) {
				matrice2[i][j] = matrice.get(i)[j];
				//System.out.print("e[" + i + "][" + j + "] = " + e[j] + " , ");
			}
			//System.out.println("");
		}
		
		for (int i = 0; i < matrice2.length; i++) {
			for (int j = 0; j < matrice2[i].length; j++) {
				if (matrice2[i][j] == null) {
					matrice2[i][j] = " ";
				}
			}
		}
		
		//System.out.println("matrice2");
		for (int i = 0; i < matrice2.length; i++) {
			for (int j = 0; j < matrice2[i].length; j++) {
				//System.out.print(matrice2[i][j] + " ");
			}
			//System.out.println();
		}
		
		
		
		//this.ruota(matrice2);
		
		
//		Integer b[][] = Rotazione.rotateMatrixCounterClockwise(new Integer[][]{{1,2,3},
//			                                                                   {4,5,6},
//			                                                                   {7,8,9}});              
		String b[][] = Rotazione.rotateMatrixCounterClockwise(matrice2);

		
		//System.out.println("ruotata");
		//this.stampa(b);
		for (int i = 0; i < b.length; i++) {
			for (int j = 0; j < b[i].length; j++) {
				System.out.print(b[i][j] + " ");
			}
			System.out.println();
		}
		
	}
	
	private int trovaMax(int[] inputInt) {
		int massimo = inputInt[0];
		for (int i = 0; i < inputInt.length; i++) {
			if (massimo < inputInt[i]) {
				massimo = inputInt[i];
			}
		}
		return massimo;
	}
	
	public static void main(String[] args) {
		new Disegna().disegna(new double[]{3,2,1,2,1});
	}

}
