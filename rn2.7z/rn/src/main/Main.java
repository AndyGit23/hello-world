package main;

import java.util.*;
import foglio.Gestione;
import grafica.Disegna;

public class Main {
	
	public static void main(String[] args) throws Exception {
		/*
		 * Monte , valle, pend-,pend+,piano
		 */
		
		HashMap<String, String> hashMap = new HashMap<String, String>();
		hashMap.put("0", "mon");
		hashMap.put("1", "val");
		hashMap.put("2", "pen-");
		hashMap.put("3", "pen+");
		hashMap.put("4", "pia=");
		Gestione gestione = new Gestione();
		ArrayList<ArrayList<String>> lista = gestione.lettura();
		lista.remove(0);
		lista.remove(20);
		
		double primo[][] = new double[lista.size()][5];
		double secondo[][] = new double[lista.size()][5];
		for (int riga = 0; riga < lista.size(); riga++) {
			ArrayList<String> record = lista.get(riga);
			for (int i = 0; i <= 4; i++) {
				primo[riga][i] = Double.parseDouble(record.get(i)) / 10; 
			}
			for (int i = 0; i <= 4; i++) {
				secondo[riga][i] = Double.parseDouble(record.get(i + 5)) / 10; 
			}
			System.out.println(lista.get(riga));
		}
		for(int i = 0; i < primo.length; i++){
			for(int j = 0; j < primo[i].length; j++){
			    System.out.print(primo[i][j] + " - ");
			    
			}
			System.out.println("");
		}
		for(int i = 0; i < secondo.length; i++){
			for(int j = 0; j < secondo[i].length; j++){
			    System.out.print(secondo[i][j] + " - ");
			}
			System.out.println("");
		}
		
		int iter = 1000000; 
		
		double learningRate = 0.1;
		
		int inp = 5;
		int hid = 5;
		int outp= 5;
		int[] layers = {inp, hid, outp};
		
		int totLayer = 3;
		
		double[] input = { 3, 2, 2, 2, 3};
		
		double[][] trainingInputs = { { 0, 0 }, { 1, 0 }, { 0, 1 }, { 1, 1 } };
	    double[][] trainingOutputs = { { 0 }, { 0 }, { 0 }, { 1 } };
			
		core.Main m = new core.Main();
		m.esegui(iter, learningRate, layers, totLayer, input, primo, secondo, hashMap);
		Disegna d = new Disegna();
		d.disegna(input);
		
		
	}
	
	private void stampa(String a[][]){
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a[i].length; j++) {
				System.out.print(a[i][j] + " ");
			}
			System.out.println();
		}
	}
	
	private void stampa(int a[][]){
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a[i].length; j++) {
				System.out.print(a[i][j] + " ");
			}
			System.out.println();
		}
	}
}







