package core;

public class Neuron {
	private int id;
	private double value;
	private double bias;
	private double delta;
	private Dendrite[] dendrites;

	public Neuron(int dendritesCount) {
		dendrites = new Dendrite[dendritesCount];
		for (int i = 0; i < dendrites.length; i++) {
			dendrites[i] = new Dendrite();
			dendrites[i].setPointsTo(i);
		}
	}

	public void setDendrites(int dendritesCount) {
		dendrites = new Dendrite[dendritesCount];
		for (int i = 0; i < dendrites.length; i++) {
			dendrites[i] = new Dendrite();
			dendrites[i].setPointsTo(i);
		}
	}

	public Dendrite getDendrite(int index) {
		return dendrites[index];
	}

	public double getDelta() {
		return delta;
	}

	public void setDelta(double delta) {
		this.delta = delta;
	}

	public int getId() {
		return id;
	}

	public void setValue(double value) {
		this.value = value;
	}

	public double getValue() {
		return value;
	}

	public void setBias(double bias) {
		this.bias = bias;
	}

	public double getBias() {
		return bias;
	}
}
