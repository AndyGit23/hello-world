package core;

public class Dendrite {
	private double weight;
	private int pointsTo;

	public Dendrite() {
		weight = 0;
		pointsTo = 0;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public void setPointsTo(int pointsTo) {
		this.pointsTo = pointsTo;
	}

	public double getWeight() {
		return weight;
	}

	public int getPointsTo() {
		return pointsTo;
	}
}
