package core;

import java.io.*;
import java.util.HashMap;
import java.util.Set;

import grafica.Disegna;

public class Main {
	
	//private int iter = 1000;
	//private int inp = 2; 
	//private int hid = 2;
	//private int outp = 1;
	
	//int[] layers = {inp,hid,outp};
	//private double learningRate = 0.1;
	//private int totLayer = 3;
	
	Disegna d = new Disegna();
	
	
	public void esegui(int iter, 
			           double learningRate, int[] layers, int totLayer,
			           double[] input,
			           double[][] trainingInputs, double[][] trainingOutputs,
			           HashMap<String, String> hashMap){
		
		PrintStream out = System.out;
		int inp = layers[0];
		int outp = layers[layers.length - 1];
		Network net = new Network(learningRate, layers, totLayer);
		double[] outputs;
		net.randomizeWeightAndBiases();
		out.println("Starting train...");
		long startTime = System.currentTimeMillis();
		for (int i = 0; i < iter; i++) {
			for (int j = 0; j < trainingInputs.length; j++) {
				net.train(trainingInputs[j], trainingOutputs[j]);
			}
		}
		out.println("End of training.");
		
		long stopTime = System.currentTimeMillis();
		long elapsedTime = (stopTime - startTime);
		System.out.println("elapsedTime =" + elapsedTime);
		
		out.println("Start test...");
		out.println();

		net.setInputs(input);
		System.out.println("Input");
		//this.stampa(input);
		d.disegna(input);
		
		outputs = net.getOutput();
		outputs = this.arrotonda(outputs, 3);

		double max = outputs[0];
		int indice = 0;
		for (int i = 0; i < outputs.length; i++) {
			out.println("Output " + i + " = " + outputs[i]);
			if (max < outputs[i]) {
				max = outputs[i];
				indice = i;
			}
		}
		System.out.println();
		System.out.println("Output max =" + max + " - " + indice);
		if (!(hashMap == null)) {
			String strIndice = String.valueOf(indice);
			String valore = hashMap.get(strIndice);
			System.out.println("Output max =" + max + " - " + valore);
		}
		
		for (int j = 0; j < 4; j++) {
			out.println("Case number " + (j + 1));
			net.setInputs(trainingInputs[j]);
			outputs = net.getOutput();
			outputs = this.arrotonda(outputs, 3);
			for (int i = 0; i < inp; i++) {
				out.println("    Input " + (i + 1) + " = " + trainingInputs[j][i]);
			}
			for (int i = 0; i < outp; i++) {
				out.println("    Output " + (i + 1) + " = " + outputs[i]);
			}
		}
	}
	
	private void stampa(double[] a){
		for (int i = 0; i < a.length; i++) {
			System.out.print(a[i] + " ");
		}
		System.out.println();
	}
	
	private void stampa2(double[][] a){
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a[i].length; j++) {
				System.out.print(a[i][j] + " ");
			}
			System.out.println();
		}
	}
	
	private double[] arrotonda(double[] outputs, int dec){
		for (int i = 0; i < outputs.length; i++) {
			outputs[i] = this.round(outputs[i], dec); 
		}
		return outputs;
	}
	
	private double round(double value, int places) {
	    if (places < 0) throw new IllegalArgumentException();
	 
	    long factor = (long) Math.pow(10, places);
	    value = value * factor;
	    long tmp = Math.round(value);
	    return (double) tmp / factor;
	} 
	
	public static void main(String[] args) throws Exception {
		
		int iter = 10000000; 
		
		double learningRate = 0.1;
		
		int inp = 2;
		int hid = 2;
		int outp= 1;
		int[] layers = {inp, hid, outp};
		
		int totLayer = 3;
		
		double[] input = { 1, 0 }; 
		
		double[][] trainingInputs = { { 0, 0 }, { 1, 0 }, { 0, 1 }, { 1, 1 }, };
	    double[][] trainingOutputs = { { 0 }, { 0 }, { 0 }, { 1 } };
			
			
		new Main().esegui(iter, learningRate, layers, totLayer, input, trainingInputs, trainingOutputs, null);
		
	}

}
