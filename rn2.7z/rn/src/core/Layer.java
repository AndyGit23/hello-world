package core;

class Layer {
	private Neuron[] neurons;

	public Layer(int size) {
		neurons = new Neuron[size];
		for (int i = 0; i < size; i++) {
			neurons[i] = new Neuron(1);
		}
	}

	public Neuron getNeuron(int index) {
		return neurons[index];
	}

	public void setNeuron(Neuron neuron, int index) {
		neurons[index] = neuron;
	}
}

