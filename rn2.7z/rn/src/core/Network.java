package core;

import java.util.Random;

class Network {
	private Random random = new Random();
	private double learningRate;
	private Layer[] layers;
	private int totLayers;
	private int[] neuronInLayer;
	private double[] netInputs;
	private double[] netOutputs;

	public Network(double learningRate, int[] layers, int totLayers) {
		if (totLayers < 2)
			throw new IllegalArgumentException("layer's count cannot be less than 2");
		this.learningRate = learningRate;
		neuronInLayer = new int[totLayers];
		this.layers = new Layer[totLayers];
		for (int i = 0; i < totLayers; i++) {
			neuronInLayer[i] = layers[i];
			this.layers[i] = new Layer(layers[i]);
		}
		netInputs = new double[layers[0]];
		netOutputs = new double[layers[totLayers - 1]];
		this.totLayers = totLayers;
	}

	public void setInputs(double[] inputs) {
		for (int i = 0; i < neuronInLayer[0]; i++) {
			layers[0].getNeuron(i).setValue(inputs[i]);
		}
	}

	public void randomizeWeightAndBiases() {
		for (int i = 0; i < totLayers; i++) {
			for (int j = 0; j < neuronInLayer[i]; j++) {
				if (i != (totLayers - 1)) {
					layers[i].getNeuron(j).setDendrites(neuronInLayer[i + 1]);
					for (int k = 0; k < neuronInLayer[i + 1]; k++) {
						layers[i].getNeuron(j).getDendrite(k).setWeight(getRand());
					}
				}
				if (i != 0) {
					layers[i].getNeuron(j).setBias(getRand());
				}
			}
		}
	}

	public double[] getOutput() {
		double[] outputs = new double[neuronInLayer[totLayers - 1]];
		for (int i = 1; i < totLayers; i++) {
			for (int j = 0; j < neuronInLayer[i]; j++) {
				layers[i].getNeuron(j).setValue(0);
				for (int k = 0; k < neuronInLayer[i - 1]; k++) {
					layers[i].getNeuron(j)
							.setValue(layers[i].getNeuron(j).getValue() + layers[i - 1].getNeuron(k).getValue()
									* layers[i - 1].getNeuron(k).getDendrite(j).getWeight());
				}
				layers[i].getNeuron(j).setValue(layers[i].getNeuron(j).getValue() + layers[i].getNeuron(j).getBias());
				layers[i].getNeuron(j).setValue(limiter(layers[i].getNeuron(j).getValue()));
			}
		}
		for (int i = 0; i < neuronInLayer[totLayers - 1]; i++) {
			outputs[i] = layers[totLayers - 1].getNeuron(i).getValue();
		}
		return outputs;
	}

	public void update() {
		getOutput();
	}

	public double limiter(double value) {
		return (1.0 / (1 + Math.exp(-value)));
	}

	public double getRand() {
		return 2 * random.nextDouble() - 1;
	}

	public double sigmaWeightDelta(int layerNumber, int neuronNumber) {
		double result = 0;
		for (int i = 0; i < neuronInLayer[layerNumber + 1]; i++) {
			result = result + layers[layerNumber].getNeuron(neuronNumber).getDendrite(i).getWeight()
					* layers[layerNumber + 1].getNeuron(i).getDelta();
		}
		return result;
	}

	public void train(double[] inputs, double[] outputs) {
		double target, actual, delta;
		setInputs(inputs);
		update();
		for (int i = totLayers - 1; i > 0; i--) {
			for (int j = 0; j < neuronInLayer[i]; j++) {
				if (i == totLayers - 1) {
					target = outputs[j];
					actual = layers[i].getNeuron(j).getValue();
					delta = (target - actual) * actual * (1 - actual);
					layers[i].getNeuron(j).setDelta(delta);
					for (int k = 0; k < neuronInLayer[i - 1]; k++) {
						double dendriteWeight = layers[i - 1].getNeuron(k).getDendrite(j).getWeight();
						dendriteWeight += delta * learningRate * layers[i - 1].getNeuron(k).getValue();
						layers[i - 1].getNeuron(k).getDendrite(j).setWeight(dendriteWeight);
					}
					layers[i].getNeuron(j).setBias(layers[i].getNeuron(j).getBias() + delta * learningRate * 1);
				} else {
					actual = layers[i].getNeuron(j).getValue();
					delta = actual * (1 - actual) * sigmaWeightDelta(i, j);
					for (int k = 0; k < neuronInLayer[i - 1]; k++) {
						double dendriteWeight = layers[i - 1].getNeuron(k).getDendrite(j).getWeight();
						dendriteWeight += delta * learningRate * layers[i - 1].getNeuron(k).getValue();
						layers[i - 1].getNeuron(k).getDendrite(j).setWeight(dendriteWeight);
					}
					if (i != 0) {
						layers[i].getNeuron(j).setBias(layers[i].getNeuron(j).getBias() + delta * learningRate * 1);
					}
				}
			}
		}
	}
}