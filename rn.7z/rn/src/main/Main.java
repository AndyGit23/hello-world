package main;

import java.util.*;

import foglio.Gestione;

import java.io.*;

public class Main {
	
	public static void main(String[] args) throws Exception {
		
		Gestione gestione = new Gestione();
		ArrayList<ArrayList<String>> lista = gestione.lettura();
		lista.remove(0);
		lista.remove(20);
		
		double primo[][] = new double[lista.size()][5];
		double secondo[][] = new double[lista.size()][5];
		for (int riga = 0; riga < lista.size(); riga++) {
			ArrayList<String> record = lista.get(riga);
			for (int i = 0; i <= 4; i++) {
				primo[riga][i] = Double.parseDouble(record.get(i)) / 10; 
			}
			for (int i = 0; i <= 4; i++) {
				secondo[riga][i] = Double.parseDouble(record.get(i + 5)) / 10; 
			}
			System.out.println(lista.get(riga));
		}
		for(int i = 0; i < primo.length; i++){
			for(int j = 0; j < primo[i].length; j++){
			    System.out.print(primo[i][j] + " - ");
			    
			}
			System.out.println("");
		}
		for(int i = 0; i < secondo.length; i++){
			for(int j = 0; j < secondo[i].length; j++){
			    System.out.print(secondo[i][j] + " - ");
			}
			System.out.println("");
		}
		
				
		
		Scanner in = new Scanner(System.in);
		PrintStream out = System.out;
		int inp = 5, hid = 5, outp = 5;
		int[] layers = { inp, hid, outp };
		out.println("Enter number of training iterations: ");
		int iter = in.nextInt();
		Network net = new Network(10, layers, 3);
		//double[] input = { 1, 0 };
		double[] input = { 1, 1, 1, 1, 1};
		double[] outputs;
		net.randomizeWeightAndBiases();
		double[][] trainingInputs = primo;
		double[][] trainingOutputs = secondo;
		//double[][] trainingInputs = { { 0, 0 }, { 1, 0 }, { 0, 1 }, { 1, 1 }, };
		//double[][] trainingOutputs = { { 0 }, { 0 }, { 0 }, { 1 } };
		/*double[][] trainingInputs = { 
			                            { 0.40, 0.30 }, 
			                            { 0.22, 0.33 }, 
			                            { 0.37, 0.37 }, 
			                            { 0.49, 0.37 },
			                            { 0.12, 0.12 }, 
			                            { 0.11, 0.11 }, 
			                            { 0.13, 0.13 }, 
			                            { 0.11, 0.88 },
			                            { 0.22, 0.77 }, 
			                            { 0.33, 0.67 }, 
			                            { 0.44, 0.56 }, 
			                            { 0.55, 0.45 },
			                            { 0.66, 0.34 }, 
			                            { 0.77, 0.23 }, 
			                            { 0.88, 0.12 },
			                            { 0.11, 0.55 }
			                            
			                        };
		double[][] trainingOutputs = { 
			                             { 0.70 }, 
			                             { 0.55 }, 
			                             { 0.74 }, 
			                             { 0.86 },
			                             { 0.24 }, 
			                             { 0.22 }, 
			                             { 0.26 }, 
			                             { 0.99 },
			                             { 0.99 }, 
			                             { 1.00 }, 
			                             { 1.00 }, 
			                             { 1.00 },
			                             { 1.00 }, 
			                             { 1.00 }, 
			                             { 1.00 }, 
			                             { 0.66 }
			                         };*/
		out.println("Starting train...");
		long startTime = System.currentTimeMillis();
		for (int i = 0; i < iter; i++) {
			for (int j = 0; j < trainingInputs.length; j++) {
				net.train(trainingInputs[j], trainingOutputs[j]);
			}
		}
		out.println("End of training.");
		
		long stopTime = System.currentTimeMillis();
		long elapsedTime = (stopTime - startTime);
		System.out.println("elapsedTime =" + elapsedTime);
		
		out.println("Start test...");

		//double input[] = {1, 0, 1, 0, 1};
		net.setInputs(input);
		outputs = net.getOutput();
		System.out.println("outputs.length =" + outputs.length);
		for (int i = 0; i < outputs.length; i++) {
			out.println("Output " + i + " " + outputs[i]);
		}

		for (int j = 0; j < 4; j++) {
			out.println("Case number: " + (j + 1));
			net.setInputs(trainingInputs[j]);
			outputs = net.getOutput();
			for (int i = 0; i < inp; i++) {
				out.println("Input: " + (i + 1) + " : " + trainingInputs[j][i]);
			}
			for (int i = 0; i < outp; i++) {
				out.println("Output: " + (i + 1) + " : " + outputs[i]);
			}
		}
	}
}

class Dendrite {
	private double weight;
	private int pointsTo;

	public Dendrite() {
		weight = 0;
		pointsTo = 0;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public void setPointsTo(int pointsTo) {
		this.pointsTo = pointsTo;
	}

	public double getWeight() {
		return weight;
	}

	public int getPointsTo() {
		return pointsTo;
	}
}

class Neuron {
	private int id;
	private double value;
	private double bias;
	private double delta;
	private Dendrite[] dendrites;

	public Neuron(int dendritesCount) {
		dendrites = new Dendrite[dendritesCount];
		for (int i = 0; i < dendrites.length; i++) {
			dendrites[i] = new Dendrite();
			dendrites[i].setPointsTo(i);
		}
	}

	public void setDendrites(int dendritesCount) {
		dendrites = new Dendrite[dendritesCount];
		for (int i = 0; i < dendrites.length; i++) {
			dendrites[i] = new Dendrite();
			dendrites[i].setPointsTo(i);
		}
	}

	public Dendrite getDendrite(int index) {
		return dendrites[index];
	}

	public double getDelta() {
		return delta;
	}

	public void setDelta(double delta) {
		this.delta = delta;
	}

	public int getId() {
		return id;
	}

	public void setValue(double value) {
		this.value = value;
	}

	public double getValue() {
		return value;
	}

	public void setBias(double bias) {
		this.bias = bias;
	}

	public double getBias() {
		return bias;
	}
}

class Layer {
	private Neuron[] neurons;

	public Layer(int size) {
		neurons = new Neuron[size];
		for (int i = 0; i < size; i++) {
			neurons[i] = new Neuron(1);
		}
	}

	public Neuron getNeuron(int index) {
		return neurons[index];
	}

	public void setNeuron(Neuron neuron, int index) {
		neurons[index] = neuron;
	}
}

class Network {
	private Random random = new Random();
	private double learningRate;
	private Layer[] layers;
	private int totLayers;
	private int[] neuronInLayer;
	private double[] netInputs;
	private double[] netOutputs;

	public Network(double learningRate, int[] layers, int totLayers) {
		if (totLayers < 2)
			throw new IllegalArgumentException("layer's count cannot be less than 2");
		this.learningRate = learningRate;
		neuronInLayer = new int[totLayers];
		this.layers = new Layer[totLayers];
		for (int i = 0; i < totLayers; i++) {
			neuronInLayer[i] = layers[i];
			this.layers[i] = new Layer(layers[i]);
		}
		netInputs = new double[layers[0]];
		netOutputs = new double[layers[totLayers - 1]];
		this.totLayers = totLayers;
	}

	public void setInputs(double[] inputs) {
		for (int i = 0; i < neuronInLayer[0]; i++) {
			layers[0].getNeuron(i).setValue(inputs[i]);
		}
	}

	public void randomizeWeightAndBiases() {
		for (int i = 0; i < totLayers; i++) {
			for (int j = 0; j < neuronInLayer[i]; j++) {
				if (i != (totLayers - 1)) {
					layers[i].getNeuron(j).setDendrites(neuronInLayer[i + 1]);
					for (int k = 0; k < neuronInLayer[i + 1]; k++) {
						layers[i].getNeuron(j).getDendrite(k).setWeight(getRand());
					}
				}
				if (i != 0) {
					layers[i].getNeuron(j).setBias(getRand());
				}
			}
		}
	}

	public double[] getOutput() {
		double[] outputs = new double[neuronInLayer[totLayers - 1]];
		for (int i = 1; i < totLayers; i++) {
			for (int j = 0; j < neuronInLayer[i]; j++) {
				layers[i].getNeuron(j).setValue(0);
				for (int k = 0; k < neuronInLayer[i - 1]; k++) {
					layers[i].getNeuron(j)
							.setValue(layers[i].getNeuron(j).getValue() + layers[i - 1].getNeuron(k).getValue()
									* layers[i - 1].getNeuron(k).getDendrite(j).getWeight());
				}
				layers[i].getNeuron(j).setValue(layers[i].getNeuron(j).getValue() + layers[i].getNeuron(j).getBias());
				layers[i].getNeuron(j).setValue(limiter(layers[i].getNeuron(j).getValue()));
			}
		}
		for (int i = 0; i < neuronInLayer[totLayers - 1]; i++) {
			outputs[i] = layers[totLayers - 1].getNeuron(i).getValue();
		}
		return outputs;
	}

	public void update() {
		getOutput();
	}

	public double limiter(double value) {
		return (1.0 / (1 + Math.exp(-value)));
	}

	public double getRand() {
		return 2 * random.nextDouble() - 1;
	}

	public double sigmaWeightDelta(int layerNumber, int neuronNumber) {
		double result = 0;
		for (int i = 0; i < neuronInLayer[layerNumber + 1]; i++) {
			result = result + layers[layerNumber].getNeuron(neuronNumber).getDendrite(i).getWeight()
					* layers[layerNumber + 1].getNeuron(i).getDelta();
		}
		return result;
	}

	public void train(double[] inputs, double[] outputs) {
		double target, actual, delta;
		setInputs(inputs);
		update();
		for (int i = totLayers - 1; i > 0; i--) {
			for (int j = 0; j < neuronInLayer[i]; j++) {
				if (i == totLayers - 1) {
					target = outputs[j];
					actual = layers[i].getNeuron(j).getValue();
					delta = (target - actual) * actual * (1 - actual);
					layers[i].getNeuron(j).setDelta(delta);
					for (int k = 0; k < neuronInLayer[i - 1]; k++) {
						double dendriteWeight = layers[i - 1].getNeuron(k).getDendrite(j).getWeight();
						dendriteWeight += delta * learningRate * layers[i - 1].getNeuron(k).getValue();
						layers[i - 1].getNeuron(k).getDendrite(j).setWeight(dendriteWeight);
					}
					layers[i].getNeuron(j).setBias(layers[i].getNeuron(j).getBias() + delta * learningRate * 1);
				} else {
					actual = layers[i].getNeuron(j).getValue();
					delta = actual * (1 - actual) * sigmaWeightDelta(i, j);
					for (int k = 0; k < neuronInLayer[i - 1]; k++) {
						double dendriteWeight = layers[i - 1].getNeuron(k).getDendrite(j).getWeight();
						dendriteWeight += delta * learningRate * layers[i - 1].getNeuron(k).getValue();
						layers[i - 1].getNeuron(k).getDendrite(j).setWeight(dendriteWeight);
					}
					if (i != 0) {
						layers[i].getNeuron(j).setBias(layers[i].getNeuron(j).getBias() + delta * learningRate * 1);
					}
				}
			}
		}
	}
}
