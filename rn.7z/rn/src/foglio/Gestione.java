package foglio;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Gestione {
	
	public ArrayList<ArrayList<String>> lettura() throws Exception {
			
			
		FileInputStream file = new FileInputStream(new File("rn.xlsx"));
			
		//Create Workbook instance holding reference to .xlsx file
		XSSFWorkbook workbook = new XSSFWorkbook(file);
			
		//Get first/desired sheet from the workbook
		XSSFSheet sheet = workbook.getSheetAt(0);
			
		ArrayList<ArrayList<String>> lista = new ArrayList<ArrayList<String>>();
			
		//Iterate through each rows one by one
		Iterator<Row> rowIterator = sheet.iterator();
		while (rowIterator.hasNext()){
			Row row = rowIterator.next();
			//For each row, iterate through all the columns
			Iterator<Cell> cellIterator = row.cellIterator();
			ArrayList<String> record = new ArrayList<String>();
			while (cellIterator.hasNext()){
				Cell cell = cellIterator.next();
				//Check the cell type and format accordingly
				String str = "";
				switch (cell.getCellTypeEnum()){
				    case NUMERIC:
				    	double d = cell.getNumericCellValue();
				    	str = String.valueOf(d);
				    	//System.out.print( str + "-");
				    	break;
				    case STRING:
				    	str = cell.getStringCellValue();
				    	//System.out.print(str + "+");
				    	break;
				    default:
				    	//System.out.print("default");
			    }
				record.add(str);
				
		    }
			//System.out.println("record =" + record);
			//System.out.println("");
			lista.add(record);
				
		}
			
		//System.out.println("lista =" + lista);
		file.close();
		
		return lista;
			
    }

}
